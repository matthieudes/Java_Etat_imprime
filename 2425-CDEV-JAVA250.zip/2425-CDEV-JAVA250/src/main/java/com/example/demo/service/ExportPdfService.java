package com.example.demo.service;

import com.example.demo.dto.FactureDto;
import com.example.demo.dto.LigneFactureDto;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.util.List;

@Service
public class ExportPdfService {

    @Autowired
    private FactureService factureService;

    public void exportFacture(Long idFacture, OutputStream outputStream) throws Exception {
        Document document = new Document();
        FactureDto factureDto = factureService.findById(idFacture);
        PdfWriter writer = PdfWriter.getInstance(document, outputStream);
        document.open();

        Paragraph paragrapheHeader = new Paragraph();
        paragrapheHeader.add(factureDto.getClientNom() + " "
                + factureDto.getClientPrenom() + "\n " );
        paragrapheHeader.setAlignment(Element.ALIGN_CENTER);
        document.add(paragrapheHeader);

        PdfPTable table = new PdfPTable(3); // 3 colonnes: Article, Quantité, Prix Unitaire
        table.setWidthPercentage(100); // Largeur du tableau à 100% du document
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        addTableHeader(table);
        for (LigneFactureDto ligne : factureDto.getLigneFactures()) {
            addRows(table, ligne);
        }
        addTotal(table, factureDto.getPrixTotal());

        document.add(table);
        Paragraph paragrapheTotal = new Paragraph();
        paragrapheTotal.add("Total : " + factureDto.getPrixTotal());

        document.close();


    }

    private void addTableHeader(PdfPTable table) {

        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);

        PdfPCell headerCell;
        headerCell = new PdfPCell(new Phrase("Article", font));
        headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(headerCell);

        headerCell = new PdfPCell(new Phrase("Quantité", font));
        headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(headerCell);

        headerCell = new PdfPCell(new Phrase("Prix Unitaire", font));
        headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(headerCell);


    }
    private void addRows(PdfPTable table, LigneFactureDto ligne) {
        table.addCell(ligne.getArticle());
        table.addCell(String.valueOf(ligne.getQuantite()));
        table.addCell(String.valueOf(ligne.getPrixUnitaire()));

    }
    private void addTotal(PdfPTable table, Double total) {
        PdfPCell cell = new PdfPCell(new Phrase("Total : " + total, FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
        cell.setColspan(3);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        table.addCell(cell);
    }
}
