package com.example.demo.service;

import com.example.demo.dto.ClientDto;

import java.util.List;

public interface ClientService {
    List<ClientDto> findAll();

}
